package com.example.tentative.view;

import android.graphics.Bitmap;
import android.graphics.Canvas;

public class Boom {

    private final Bitmap bitmap; //use for displaying boom picture
    private final int x,y; //the position
    private int time; //timer

    public Boom(Bitmap bitmap, int x, int y) {
        this.bitmap = bitmap;
        this.x = x;
        this.y = y;
        this.time = 12; //used to keep track of how long the boom will stay on screen, adjust value for how long you want it to stay on screen
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(bitmap, x, y, null);
    }

    public void update() { //each update will decrease the value of lifetime
        time--;
    } //make timer go down

    public boolean isAlive() { //boom remaining on screen
        return time > 0;
    } //used to check on whether the boom will stay on screen
}
