package com.example.tentative;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tentative.view.GameState;

public class Gameover extends AppCompatActivity {
    TextView score;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_over);

        // Get the score from the game state
        int points = GameState.getScore();

        score = findViewById(R.id.Points);
        score.setText(String.valueOf(points)); //display score
    }

    public void restart(View v){ //restart the game
        startActivity(new Intent(this,MainActivity.class));
        finish();
    }

    public void exit(View v){ //navigate back to the home screen for phone
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}