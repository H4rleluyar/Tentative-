package com.example.tentative.view;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.example.tentative.Gameover;
import com.example.tentative.R;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class GameState extends View {

    // Store the movable area. Change values in onSizeChanged here
    protected int[] movableArea = new int[4];

    public static int score = 0; //point counter
    boolean alienShooting = false;



    Context context;
    PlayerSpaceShip player; //player spaceship
    Set<Laser> shots;
    Set<Laser> enemyShots;
    Iterator<Laser> iterate;

    private List<AlienSpaceShip> aliens; //list to store 1 or multiple alien shipshit
    List<Boom> explosions = new ArrayList<>(); //list to store boom png

    Paint scorePaint = new Paint();
    Paint lifePaint = new Paint();

    public GameState(Context context) {
        this(context, null);
        aliens = new ArrayList<>();
    }


    public void setScore(int newScore) { //get the score of total score of game
        score = newScore;
    } //used to set the score

    public void spawnAlien() { //spawn alien ship

        aliens.add(new AlienSpaceShip(getContext()));

    }

    public GameState(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public GameState(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        this.context = context;

        shots = new HashSet<>();
        enemyShots = new HashSet<>();
        setScore(0); //set score back to zero

        aliens = new ArrayList<>();
        spawnAlien(); //create alien on screen
    }

    public void setPlayer(PlayerSpaceShip p){
        player = p;
    } //set the player spaceship

    public void addShot(Laser e){
        shots.add(e);
    }

    // End the game and move to Game Over screen
    private void gameOver(){
        Intent intent = new Intent(context, Gameover.class);
        intent.putExtra("points", score);
        context.startActivity(intent);
        ((Activity) context).finish();
    }

    /**
     *
     * @param boomSelection: R identifier for boom image drawable
     * @param explodeX: x position of explosion
     * @param explodeY: y position of explosion
     * @return a new Boom instance for displaying boom upon collision
     */
    private Boom createBoom(int boomSelection, int explodeX, int explodeY){
        return new Boom(
                BitmapFactory.decodeResource(getResources(), boomSelection), // boom image selection

                //display at position
                explodeX,
                explodeY
        );
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        //player dies
        //switch to game over screen
        if(player.life == 0)
            gameOver();

        for (AlienSpaceShip alien : aliens) {
            alien.move();
            canvas.drawBitmap(alien.getAlienSpaceShip(), alien.alienX, alien.alienY, null);

            //alien shots
            if(!alienShooting && alien.rand.nextInt(100) > 97){
                float deg = (float) Math.atan2(player.hitbox.centerY() - alien.alienY,player.hitbox.centerX() -  alien.alienX);
                Matrix rotate = new Matrix();
                rotate.setRotate((float) Math.toDegrees(deg)); //rotate the matrix
                Laser alienLaser = new Laser(context, rotate, alien.alienX, alien.alienY, deg);
                enemyShots.add(alienLaser);
                alienShooting = true;
            }


            //check for collision with player's laser
            for (Iterator<Laser> iterator = shots.iterator(); iterator.hasNext(); ) {
                Laser laser = iterator.next();
                for (Iterator<AlienSpaceShip> alienIterator = aliens.iterator(); alienIterator.hasNext(); ) {
                    alien = alienIterator.next();
                    if (alien.checkCollision(laser.hitbox)) {
                        iterator.remove();
                        alienIterator.remove();
                        score++; //increment the score
                        spawnAlien();//spawn another alien after it gets destroy

                        //used bigger boom.png for ship; display at alien position
                        explosions.add(createBoom(R.drawable.boom6, alien.alienX,alien.alienY));
                    }
                }
            }
        }


        //check for player collision with alien's laser
        for (Iterator<Laser> iterator = enemyShots.iterator(); iterator.hasNext(); ) {
            Laser laser = iterator.next();
                if (player.checkCollision(laser.hitbox)) {
                    iterator.remove();

                    // use smaller boom.png for player; display at player's position
                    explosions.add(createBoom(R.drawable.boom5, player.playerX, player.playerY));
                    player.life = Math.max(0, player.life - 1); //decrement the player health
                }
        }

        for (Iterator<Boom> iterator = explosions.iterator(); iterator.hasNext();) { //iterate through boom class to update the information for rendering it
            Boom explosion = iterator.next();
            explosion.update();
            if (!explosion.isAlive()) { //if time is below 0 then we remove the boom png from screen
                iterator.remove();
            } else {
                explosion.draw(canvas);
            }
        }

        // Move and redraw player shots
        for (iterate = shots.iterator(); iterate.hasNext();){
            // Iterate through all shots
            Laser i = iterate.next();

            if (i.outOfBounds()) {
                // Laser has moved out of bounds; garbage collect it and remove it from visible shots
                i.garbageCollect();
                iterate.remove();
                continue;
            }

            // Move laser
            i.laserX += i.velocityX;
            i.laserY += i.velocityY;

            // Redraw and update hitbox
            canvas.drawBitmap(i.laser, i.laserX, i.laserY, null);
            i.updateHitbox();
        }

        //enemyshots
        for (iterate = enemyShots.iterator(); iterate.hasNext();){

            Laser i = iterate.next();

            if (i.outOfBounds()) {
                i.garbageCollect();
                iterate.remove();
                continue;
            }

            i.laserX += i.velocityX;
            i.laserY += i.velocityY;

            canvas.drawBitmap(i.laser, i.laserX, i.laserY, null);

            i.updateHitbox();
        }

        //allow alien to shoot after lasers have been removed
        if(enemyShots.size() == 0){
            alienShooting = false;
        }


        scorePaint.setColor(Color.WHITE); //set score color to white
        scorePaint.setTextSize(50); //set size for text
        canvas.drawText("Score: " + score, 50, 50, scorePaint); //draw on screen


        lifePaint.setColor(Color.WHITE);  //set score color to white
        lifePaint.setTextSize(50); //set size for text
        canvas.drawText("Health: " + player.life, 50, 100, lifePaint); //draw on screen

        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        /*
        Edit the movable area for the player in here
        Position Convention:
            0 = Top border
            1 = Bottom border
            2 = Left border
            3 = Right border
         */
        movableArea[0] = (int) (h/2.5);
        movableArea[1] = h;
        movableArea[2] = 0;
        movableArea[3] = w;

        player.updateMoveArea();

        Laser.setScreenSize(w, h);
    }

    public int[] getMovableArea(){
        return movableArea;
    } //get which area is moveable

    public static int getScore() { //get the score of total score of game
        return score;
    } //get the score for the game

}
