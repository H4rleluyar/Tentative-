package com.example.tentative.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import com.example.tentative.R;

public class Laser {
    Bitmap laser;
    Context context;
    int laserX, laserY; // position
    static final double SPEED_FACTOR = 60; //set the laser speed
    Rect hitbox; // hitbox

    static int width, height; // width and height of laser
    static int screenWidth, screenHeight; // width and height of playable screen. to detect if laser has moved out of bounds

    static final double SCALE_FACTOR = 2; // scale size of laser

     float velocityX, velocityY; // velocity vector components

    public Laser(Context context, Matrix rotation, int startingX, int startingY, float deg){ //laser object to be used by player's and alien for shooting
        this.context = context;

        // Create and scale laser bitmap
        laser = BitmapFactory.decodeResource(context.getResources(), R.drawable.laser1);

        width = (int) (laser.getWidth() * SCALE_FACTOR);
        height = (int) (laser.getHeight() * SCALE_FACTOR);

        laser = Bitmap.createScaledBitmap(laser, width, height, false);

        laser = Bitmap.createBitmap(laser, 0,0,width,height, rotation, false);

        // Set startingX, startingY as the center of the laser. laserX and laserY point to the top-left corner of bitmap.
        laserX = startingX - width/2;
        laserY = startingY - height/2;

        // Compute x and y component velocities. All lasers go at SPEED_FACTOR
        velocityX = (float) (SPEED_FACTOR * Math.cos(deg));
        velocityY = (float) (SPEED_FACTOR * Math.sin(deg));

        hitbox = new Rect();
    }

    // Update the hitbox
    public void updateHitbox(){
        hitbox.set(laserX, laserY, laserX + width, laserY + height);
    }

    // Set screen size bounds
    static void setScreenSize(int width, int height) {
        screenWidth = width;
        screenHeight = height;
    }

    // Return true if laser is now out of bounds and not visible on the screen. Return false if within bounds.
    boolean outOfBounds(){
        return (hitbox.right < 0 || hitbox.left > screenWidth || hitbox.bottom < 0 || hitbox.top > screenHeight);
    }

    // Garbage collect this laser instance
    void garbageCollect(){
        System.gc();
    }
}
