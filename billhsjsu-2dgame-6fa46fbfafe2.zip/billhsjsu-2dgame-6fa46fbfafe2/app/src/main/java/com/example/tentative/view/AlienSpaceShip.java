package com.example.tentative.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.example.tentative.R;

import java.util.Random;

public class AlienSpaceShip {

    Bitmap alienSpaceShip; //use for displaying alien spaceship
    Random rand; //used for random movement and spawn point
    Context context;
    int alienX,alienY; //position of alien spaceship
    int alienVelocity; //use for speed of ship

    private final Rect hitbox; // alien hitbox


    public AlienSpaceShip(Context context){ //load in alien space ship with with positon
        this.context = context;
        alienSpaceShip = BitmapFactory.decodeResource(context.getResources(), R.drawable.alien2); //set alien spaceship to picture
        rand = new Random();
        resetAlienShipPosition();
        hitbox = new Rect(alienX, alienY, alienX + alienSpaceShip.getWidth(), alienY + alienSpaceShip.getHeight());

    }

    public Bitmap getAlienSpaceShip(){ //return alienSpaceShip bitmap
        return alienSpaceShip;
    }

    private void resetAlienShipPosition() { //spawn alien ship on random x axis with random speed
        DisplayMetrics displayMetrics = new DisplayMetrics(); //used to get information about screen : source https://twiserandom.com/android/util/the-displaymetrics-class-in-android-a-tutorial/index.html
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;

        alienX = rand.nextInt(width -  alienSpaceShip.getWidth()); //spawn in random x axis
        alienY= 0; //spawn in same y axis
        alienVelocity = 9 + rand.nextInt(6);   //change value here to make alien's speed movement chang
    }

    public void move() {
        //Move the alien along the x-axis
        if (alienX < 0) {
            alienVelocity = Math.abs(alienVelocity); //change direction
        } else if (alienX > Laser.screenWidth - alienSpaceShip.getWidth()) {
            alienVelocity = -Math.abs(alienVelocity); //change direction
        }

        //2% chance to change direction, dont make this bigger than 5 bc it will cause jittery movement
        if (new Random().nextInt(100) < 2) {
            alienVelocity = -alienVelocity;
        }

        alienX += alienVelocity;

        //update hitbox position
        hitbox.set(alienX, alienY, alienX + alienSpaceShip.getWidth(), alienY + alienSpaceShip.getHeight());

        //reset alien's position if it goes off screen
        if (alienY > Laser.screenHeight) {
            resetAlienShipPosition();
        }
    }



    public boolean checkCollision(Rect laserHitbox) { //check for collision with laser
        return hitbox.intersect(laserHitbox);
    }


}

