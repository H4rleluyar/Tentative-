package com.example.tentative.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import com.example.tentative.R;

public class PlayerSpaceShip extends View {

    // we copy values to within same object for performance. edit values of movableArea in onSizeChanged() within GameState to adjust area
    private static int MOVABLE_TOP, MOVABLE_DOWN, MOVABLE_LEFT, MOVABLE_RIGHT;

    private GameState game; // game information
    private final Context context;

    private Bitmap playerSpaceShip; //use for displaying player spaceship
    private static Bitmap originalMap; // store player bitmap before applying changes (e.g. rotation)
    int width, height; // width and height of player

    int playerX, playerY; // position of player spaceship
    int life = 5; // health points
    Rect hitbox; // player hitbox


    private static final double SCALE_FACTOR = 0.55; // scale size proportional

    private final Matrix matrix; // rotation matrix
    private float pivotX, pivotY; // pivot position for dragging/clicking
    private boolean currentlyMoving = false; // differentiate moving and clicking/shooting
    private final float[] facingDirection = new float[9]; // store matrix values of rotation


    public PlayerSpaceShip(Context context, @Nullable AttributeSet attrs, int defStyleAttr){
        super(context, attrs, defStyleAttr);
        this.context = context;

        // set the original bitmap scaled to the SCALE_FACTOR
        originalMap = BitmapFactory.decodeResource(context.getResources(), R.drawable.ship1);
        originalMap = Bitmap.createScaledBitmap(originalMap, width = (int) (originalMap.getWidth() * SCALE_FACTOR) , height = (int) (originalMap.getHeight() * SCALE_FACTOR), false);

        playerSpaceShip = Bitmap.createBitmap(originalMap); // the bitmap to be displayed on screen

        // initialize rotation matrix and hitbox
        matrix = new Matrix();
        hitbox = new Rect();
    }


    public PlayerSpaceShip(Context context, @Nullable AttributeSet attrs){
        this(context, attrs, 0);
    }

    public PlayerSpaceShip(Context context){
        this(context, null);
    }

    public void setGameState(GameState g){ game = g; }

    // NOTE: To be set and called within GameState
    protected void updateMoveArea(){
        int[] area = game.getMovableArea();

        // Follow order predefined in GameState
        MOVABLE_TOP = area[0];
        MOVABLE_DOWN = area[1];
        MOVABLE_LEFT = area[2];
        MOVABLE_RIGHT = area[3];
    }
    public boolean checkCollision(Rect laserHitbox) { //check for collision with laser
        return hitbox.intersect(laserHitbox);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        // Set the player to be in the middle of screen
        playerX = w/2 - width/2;
        playerY = h/2 - height/2;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Draw spaceship on the canvas and update the hitbox
        canvas.drawBitmap(playerSpaceShip, playerX,playerY,null);
        hitbox.set(playerX, playerY, playerX + width, playerY + height);
    }

    private void setPivotMousePoint(float x, float y) {
        pivotX = x;
        pivotY = y;
    }

    @Override
    public boolean performClick() {
        // Get rotation degree to face click position
        float deg = (float) Math.atan2(pivotY - hitbox.centerY(), pivotX - hitbox.centerX());
        matrix.setRotate((float) Math.toDegrees(deg) + 90, hitbox.centerX(), hitbox.centerY()); // +90 degrees because ship drawable is vertical
        matrix.getValues(facingDirection);

        // Rotate the bitmap
        Bitmap oldShip = playerSpaceShip; // To be garbage collected
        playerSpaceShip = Bitmap.createBitmap(originalMap, 0, 0, originalMap.getWidth(), originalMap.getHeight(), matrix, false);

        // Update the width and height to fit rotated bitmap
        width = playerSpaceShip.getWidth();
        height = playerSpaceShip.getHeight();

        // Garbage collect the old ship bitmap and draw the new bitmap
        oldShip.recycle();
        invalidate();

        // Create laser towards click position
        matrix.setRotate((float) Math.toDegrees(deg), hitbox.centerX(), hitbox.centerY()); // Rotate laser. No offset because laser drawable is horizontal
        game.addShot(new Laser(context, matrix, hitbox.centerX(), hitbox.centerY(), deg));

        super.performClick();
        return true;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) { //handle touch on screen

        float x = event.getX();
        float y = event.getY();

        switch (event.getAction()){

            case MotionEvent.ACTION_DOWN:
                // Set a pivot point to be able to drag from anywhere
                setPivotMousePoint(x,y);
                break;


            case MotionEvent.ACTION_MOVE:

                currentlyMoving = true; // differentiate dragging and shooting

                // Calculate drag movement from pivot point
                float tempX = playerX + x - pivotX;
                float tempY = playerY + y - pivotY;

                // We split x and y to allow moving along a border

                // Bound the player within MOVABLE_TOP and MOVABLE_DOWN
                if (tempY >= MOVABLE_TOP && tempY + height <= MOVABLE_DOWN)
                    playerY = (int) tempY;

                // Bound the player within MOVABLE_LEFT and MOVABLE_RIGHT
                if (tempX >= MOVABLE_LEFT && tempX + width <= MOVABLE_RIGHT)
                    playerX = (int) tempX;

                invalidate();

                setPivotMousePoint(x,y); // update pivot point as we drag
                break;


            case MotionEvent.ACTION_UP:
                if (currentlyMoving) {
                    // Currently being dragged; complete movement
                    currentlyMoving = false;
                    break;
                }

                // Otherwise, click/shoot
                performClick();
                break;
        }

        return true;
    }

}
