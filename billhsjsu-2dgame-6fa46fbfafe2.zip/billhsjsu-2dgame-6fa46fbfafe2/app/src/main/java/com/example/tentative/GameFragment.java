package com.example.tentative;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.tentative.databinding.FragmentGameBinding;
import com.example.tentative.view.GameState;
import com.example.tentative.view.PlayerSpaceShip;

public class GameFragment extends Fragment {
    PlayerSpaceShip player;
    GameState gameState;

    public GameFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        FragmentGameBinding binding = FragmentGameBinding.inflate(inflater);

        gameState = binding.gameInfo;
        player = binding.player;

        player.setGameState(gameState);
        gameState.setPlayer(player);

        return binding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();
    }
}